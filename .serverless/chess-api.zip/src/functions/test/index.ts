// import { APIGatewayProxyEvent } from "aws-lambda";
const APIGatewayProxyEvent = require("aws-lambda");

module.exports.getTestTable = async () => {
    // console.log("event\n", event);
    try {
        return JSON.stringify({
            statusCode: 200,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Credentials": true,
            },
            body: {
                msg: "hello-"
            },
        });
    } catch (error) {
        console.log("error\n", error);
    }
}